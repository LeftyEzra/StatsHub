from django.apps import AppConfig


class BBallConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'B_Ball'
