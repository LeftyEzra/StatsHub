from django import forms
from .models import Team

class TeamForm(forms.ModelForm):
    class Meta:
        model = Team
        fields = [
            'team_name', 'team_logo', 'team_abbreviation',
            'team_head_coach', 'head_coach_photo',
            'team_assitance_coach1', 'assitance_coach1_photo',
            'team_assitance_coach2', 'assitance_coach2_photo'
        ]

        labels = {
            'team_name': 'Enter Team Name',
            'team_logo': 'Team Logo',
            'team_abbreviation': 'Team Abbreviation',
            'team_head_coach': 'Team Head Coach',
            'head_coach_photo': 'Head Coach Photo',
            'team_assitance_coach1': 'Assistant Coach 1',
            'assitance_coach1_photo': 'Assistant Coach 1 Photo',
            'team_assitance_coach2': 'Assistant Coach 2',
            'assitance_coach2_photo': 'Assistant Coach 2 Photo',
        }

        widgets = {
            'team_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Team Name'}),
            'team_logo': forms.ClearableFileInput(attrs={'class': 'form-control'}),
            'team_abbreviation': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Team Abbreviation'}),
            'team_head_coach': forms.TextInput(attrs={'class': 'form-control', 'placeholder': "Team Head Coach's Name"}),
            'head_coach_photo': forms.ClearableFileInput(attrs={'class': 'form-control'}),
            'team_assitance_coach1': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Assistant Coach Name'}),
            'assitance_coach1_photo': forms.ClearableFileInput(attrs={'class': 'form-control'}),
            'team_assitance_coach2': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Assistant Coach Name'}),
            'assitance_coach2_photo': forms.ClearableFileInput(attrs={'class': 'form-control'}),
        }
