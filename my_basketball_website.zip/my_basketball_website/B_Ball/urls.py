from django.urls import path
from . import views
#from .views import OrganizerCompetitionsView, GetGamesByDate


from my_basketball_website.B_Ball.views.organizer_views import OrganizerCompetitionsView
from my_basketball_website.B_Ball.views.game_schedule_views import GetGamesByDate

#Api urls
#from .views import CompetitionListAPI, CompetitionDetailAPI, GameScheduleListAPI, GameScheduleDetailAPI

urlpatterns = [
                #Extras
                path('', views.home, name='home'),
                path('search_team/', views.search_teams_players, name='search-teams-players'),
                path('about/', views.about, name='about'),

                # Organizers
                path('organizers/<int:pk>/', OrganizerCompetitionsView.as_view(), name='organizer-competitions'),
                path('organizers/<int:competition_id>/games/<str:date>/', GetGamesByDate.as_view(), name='games-by-date'),


##Competion Urls
                #path('fiba_women_qualifiers_2024/', views.fiba_women_qualifiers_2024, name='fiba-women-qualifiers-2024'),
                #path('competitions/<int:pk>/', views.CompetitionDetailView.as_view(), name='competition-detail'),
                #path('competitions/<int:competition_pk>/teams/<int:pk>/', views.TeamDetailView.as_view(), name='team-detail'),
                #path('teams/<int:pk>/', views.TeamDetailView.as_view(), name='team-detail'

                # Teams urls
                path('forms_db/', views.forms_db, name='forms-db'),
                path('list_all_teams', views.list_all_teams, name='list-all-teams'),
                path('teams_id/<int:pk>/', views.teams_id, name='teams-id'),
                path('update_team/<int:pk>/', views.update_team, name='update-team'),
                path('delete_team/<int:pk>/', views.delete_team, name='delete-team'),
                path('team_roster/<int:pk>/', views.team_roster, name='team-roster'),

                #Players
                path('stats_tables/<int:game_pk>', views.stats_tables, name='table'),


                #Games urls
                path('game_schedule/', views.game_schedule, name='game-schedule'),
                path('game_summary/<int:pk>/', views.game_summary, name='game-summary'),






                #Api url paths
                #path('api/competitions/', CompetitionListAPI.as_view(), name='competition-list'),
                #path('api/competitions/<int:pk>/', CompetitionDetailAPI.as_view(), name='competition-detail'),
                #path('api/games/', GameScheduleListAPI.as_view(), name='game-schedule-list'),
                #path('api/games/<int:pk>/', GameScheduleDetailAPI.as_view(), name='game-schedule-detail'),




               ]


