from django.shortcuts import render, get_object_or_404
from django.shortcuts import render, redirect
from django.views.generic import DetailView
from django.views import View

from django.http import HttpResponseRedirect
from django.http import JsonResponse
from django.contrib import messages
from .models import PlayersStats, Player, Team, BackgroundImages, GameSchedule,QuarterlyScores, Organizer,  Competition
from django.db.models import Q
from .forms import TeamForm

from django.db.models import Sum, F, Value, IntegerField
from django.db.models.functions import Cast # Casting string to integer
from django.db.models import Sum

from datetime import datetime, timedelta # Module to represent the fifference between two dates
from django.utils.timezone import now
from django .utils import timezone
from calendar import HTMLCalendar




"""


GameSchedule.objects.filter(...)
GameSchedule: model that holds the game schedules.
objects: Manager for interacting with the database.
filter(...): This is used to get records that match certain conditions.
competition_game_schedule=competition
competition_game_schedule: This is the ForeignKey field in your GameSchedule model that links to the Competition model.
competition: This is the current competition instance being processed in the loop.
date=current_date

current_date: This is the specific date being processed in the loop.
.distinct()
distinct(): This ensures that the query returns distinct records, so you don't get duplicate entries.
Date: For each date within the competition's date range, you fetch game schedules.
Filter: You filter the game schedules by the competition and date.
Distinct: Ensures no duplicates in the results.

"""








# Create your views here.


#find . -path "*/migrations/*.py" -not -name "__init__.py" -delete
#find . -path "*/migrations/*.pyc"  -delete




"""import datetime

first_date = datetime.datetime(year=2024, month=1, day=1)
second_date = datetime.datetime(year=2024, month=5, day=27)
interval = second_date - first_date
"""


class OrganizerCompetitionsView(View):
    def get(self, request, pk, *args, **kwargs):
        organizer = get_object_or_404(Organizer, pk=pk)
        competitions = Competition.objects.filter(organizers=organizer)

        competitions_with_dates = []
        for competition in competitions:
            date_range = []
            current_date = competition.start_date
            while current_date <= competition.end_date:
                games = GameSchedule.objects.filter(competition_game_schedule=competition, date=current_date).distinct()
                date_range.append({'date': current_date, 'games': list(games)})
                current_date += timedelta(days=1)
            competitions_with_dates.append({
                'competition': competition,
                'dates': date_range,
            })

        teams = Team.objects.filter(competition__in=competitions).distinct()

        context = {
            'organizer': organizer,
            'competitions': competitions,
            'competitions_with_dates': competitions_with_dates,
            'teams': teams,
        }

        return render(request, 'organizer_competitions.html', context)


class GetGamesByDate(View):
    def get(self, request, competition_id, date):
        competition = get_object_or_404(Competition, pk=competition_id)
        games = GameSchedule.objects.filter(competition_game_schedule=competition, date=date).distinct()

        return render(request, 'organizer_competitions.html', {'games': games})


"""
class OrganizerCompetitionsView(View):
    def get(self, request, pk, *args, **kwargs):
        organizer = get_object_or_404(Organizer, pk=pk)
        competitions = Competition.objects.filter(organizers=organizer)

        # Calculate date ranges and games for each competition
        competitions_with_dates_and_games = []
        #competitions_with_dates_and_games: This list holds data for each competition. For each competition, 
        #it includes dates, and for each date, it includes games.

        #Looping through each competition, then each date within that competition. 
        #For each date, i fetch games scheduled for that date and store them.
        for competition in competitions:
            date_range = []
            games_by_date = {}
            current_date = competition.start_date
            while current_date <= competition.end_date:
                date_range.append(current_date)
                games = GameSchedule.objects.filter(competition_game_schedule=competition, date=current_date).distinct()
                games_by_date[current_date] = games
                current_date += timedelta(days=1)
            competitions_with_dates_and_games.append({
                'competition': competition,
                'dates': date_range,
                'games_by_date': games_by_date,
            })

        # Fetch teams related to the competitions of this organizer
        teams = Team.objects.filter(competition__in=competitions).distinct()

        context = {
            'organizer': organizer,
            'competitions_with_dates_and_games': competitions_with_dates_and_games,
            'teams': teams,
        }
        return render(request, 'organizer_competitions.html', context)"""


#Game summary view
def game_summary(request, pk):
    game = get_object_or_404(GameSchedule, pk=pk)
    quarterly_scores = get_object_or_404(QuarterlyScores, game=game)

    context = {
        'game': game,
        'quarterly_scores': quarterly_scores,
    }
    return render(request, 'game_summary.html', context)





# Delete Team(s)
def delete_team(request, pk):
    team = get_object_or_404(Team, pk=pk)
    team.delete()
    # Return an 'invalid login' error message.
    messages.success(request, (" Team deleted successfully):"))
    return redirect('list-all-teams')


# Update Team Views
def update_team(request, pk):

    # team_details = Team.object.get(id=pk)
    update_teams = get_object_or_404(Team, pk=pk)
    form = TeamForm(request.POST or None, instance=update_teams )

    if form.is_valid():
        form.save()
        # Return an 'invalid login' error message.
        messages.success(request, (" Team Updated Sucessfully ):"))
        return redirect('list-all-teams')
    return render(request, 'update_team.html', {'update_teams': update_teams,
                                                'form':form, })




#Forms to database view
def forms_db(request):
    submitted = False
    if request.method == "POST":
        form = TeamForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            # Return an 'invalid login' error message.
            messages.success(request, (" Team Added Successfully ):"))
            return HttpResponseRedirect('/forms_db?submitted=True')
    else:
        form = TeamForm
        if 'submitted' in request.GET:
            submitted = True

    return render(request, 'forms.html', {"form" : form, 'submitted':submitted})



# Search team view
def search_teams_players(request):
    if request.method == "POST":
        searched = request.POST.get('searched')
        searched = Team.objects.filter(Q(team_name__icontains=searched) | Q(team_abbreviation__icontains=searched)) # Query the Database for the teams
        if not searched:
            # Return an 'invalid search' error message.
            messages.success(request, (" Team not in list. Please search another team ):"))
            return render(request, 'search_teams_players.html',
                          {})
        else:
            return render(request, 'search_teams_players.html',
                      {'searched': searched})
    else:
        return render(request, 'search_teams_players.html',
                      {})


#Team Roster
def team_roster(request,pk):

    teams_details = get_object_or_404(Team, pk=pk)
    players = teams_details.players.all()  # Using the foreign key Team related_name  'players'
    return render(request, 'team_roster.html', {'team_details': teams_details, 'players': players})




def teams_id(request, pk):
    team_details = get_object_or_404(Team, pk=pk)
    team_images = BackgroundImages.objects.filter(team_pictures=team_details)
    players = team_details.players.all()  # Using the foreign key Team related_name 'players'
    games = GameSchedule.objects.all()


    context = {
        'team_details': team_details,
        'team_images': team_images,
        'games': games,
        'players': players,
        'timestamp': now().timestamp(),  # Generate a unique timestamp to ensure that the browser loads the latest version of the .js file
    }
    return render(request, 'team_details.html', context)


def list_all_teams(request):
    teams = Team.objects.all()
    for team in teams:
        print(f"Team: {team.team_name}, Logo: {team.team_logo}")
        if not team.team_logo:
            team.team_logo = 'uploads/Team_Logos/default_logo.png'
    return render(request, 'list_all_teams.html', {'teams': teams})


def stats_tables(request, game_pk):
    game = get_object_or_404(GameSchedule, pk=game_pk) # Game played
    home_team = game.home_team # Home team
    away_team = game.away_team # Away Team

    home_team_players = PlayersStats.objects.filter(player_team=home_team).order_by('-points') # Home team players stats
    away_team_players = PlayersStats.objects.filter(player_team=away_team).order_by('-points') # Away team players stats

    # Using django aggregate function to calculate the sum of all the players stats metrics
    home_totals = home_team_players.aggregate(

        points=Sum('points'),
        field_goal_attempts=Sum('field_goal_attempts'),
        field_goal_made=Sum('field_goal_made'),

        point_3_attempts=Sum('point_3_attempts'),
        point_3_made = Sum('point_3_made'),

        point_2_attempts = Sum('point_2_attempts'),
        point_2_made = Sum('point_2_made'),

        ft_attempts=Sum('ft_attempts'),
        ft_made = Sum('ft_made'),

        offensive_rebs = Sum('offensive_rebs'),
        defensive_rebs = Sum('defensive_rebs'),
        total_rebounds = Sum('total_rebounds'),
        blocks = Sum('blocks'),
        assists = Sum('assists'),
        steals = Sum('steals'),
        turnovers = Sum('turnovers'),
        personal_fouls = Sum('personal_fouls'),
        plus_minus=Sum(Cast(F('plus_minus'), IntegerField())),
        efficiency=Sum(Cast(F('efficiency'), IntegerField()))

    )
    # Calculating the percentages manually
    # The if conditional statement is to print 0 if no attempts is recorded
    home_totals['fg_percent'] = (home_totals['field_goal_made'] / home_totals['field_goal_attempts'] * 100) if home_totals['field_goal_attempts'] else 0
    home_totals['point_3_percent'] = (home_totals['point_3_made'] / home_totals['point_3_attempts'] * 100) if home_totals['point_3_attempts'] else 0
    home_totals['point_2_percent'] = (home_totals['point_2_made'] / home_totals['point_2_attempts'] * 100) if home_totals['point_2_attempts'] else 0
    home_totals['ft_percent'] = (home_totals['ft_made'] / home_totals['ft_attempts'] * 100) if home_totals['ft_attempts'] else 0


    # Using django aggregate function to calculate the sum of all the players stats metrics
    away_totals = away_team_players.aggregate(

        points=Sum('points'),
        field_goal_attempts=Sum('field_goal_attempts'),
        field_goal_made=Sum('field_goal_made'),

        point_3_attempts=Sum('point_3_attempts'),
        point_3_made=Sum('point_3_made'),

        point_2_attempts=Sum('point_2_attempts'),
        point_2_made=Sum('point_2_made'),

        ft_attempts=Sum('ft_attempts'),
        ft_made=Sum('ft_made'),

        offensive_rebs=Sum('offensive_rebs'),
        defensive_rebs=Sum('defensive_rebs'),
        total_rebounds=Sum('total_rebounds'),
        blocks=Sum('blocks'),
        assists=Sum('assists'),
        steals=Sum('steals'),
        turnovers=Sum('turnovers'),
        personal_fouls=Sum('personal_fouls'),
        plus_minus=Sum(Cast(F('plus_minus'), IntegerField())),
        efficiency=Sum(Cast(F('efficiency'), IntegerField()))
    )

    # Calculating the percentages manually
    # The if conditional statement is to print 0 if no attempts is recorded
    away_totals['fg_percent'] = (away_totals['field_goal_made'] / away_totals['field_goal_attempts'] * 100) if away_totals['field_goal_attempts'] else 0
    away_totals['point_3_percent'] = (home_totals['point_3_made'] / away_totals['point_3_attempts'] * 100) if away_totals['point_3_attempts'] else 0
    away_totals['point_2_percent'] = (away_totals['point_2_made'] / away_totals['point_2_attempts'] * 100) if away_totals['point_2_attempts'] else 0
    away_totals['ft_percent'] = (away_totals['ft_made'] / away_totals['ft_attempts'] * 100) if away_totals['ft_attempts'] else 0

    return render(request, 'tables.html', {
        'home_team_players': home_team_players,
        'away_team_players': away_team_players,
        'home_team': home_team,
        'away_team': away_team,
        'home_totals': home_totals,
        'away_totals': away_totals,
    })





# Home view
def home(request):

    time = datetime.now().strftime("%H:%M")
    players = Player.objects.all().order_by('jersey_numbers')

    return render(request, 'home.html', {'players':players})

# About view
def about(request):


    return render(request, 'about.html',)


def game_schedule(request):
    return render(request, 'game_schedule.html', {})





##########################################################################
######################### API VIEWS #############################
###############################################################################

"""from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404
from .models import Competition, GameSchedule
from .serializers import CompetitionSerializer, GameScheduleSerializer

class CompetitionListAPI(APIView):
    def get(self, request, format=None):
        competitions = Competition.objects.all()
        serializer = CompetitionSerializer(competitions, many=True)
        return Response(serializer.data)

    def post(self, request, format=None):
        serializer = CompetitionSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class CompetitionDetailAPI(APIView):
    def get_object(self, pk):
        return get_object_or_404(Competition, pk=pk)

    def get(self, request, pk, format=None):
        competition = self.get_object(pk)
        serializer = CompetitionSerializer(competition)
        return Response(serializer.data)

    def put(self, request, pk, format=None):
        competition = self.get_object(pk)
        serializer = CompetitionSerializer(competition, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk, format=None):
        competition = self.get_object(pk)
        competition.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

class GameScheduleListAPI(APIView):
    def get(self, request, format=None):
        games = GameSchedule.objects.all()
        serializer = GameScheduleSerializer(games, many=True)
        return Response(serializer.data)

    def post(self, request, format=None):
        serializer = GameScheduleSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class GameScheduleDetailAPI(APIView):
    def get_object(self, pk):
        return get_object_or_404(GameSchedule, pk=pk)

    def get(self, request, pk, format=None):
        game = self.get_object(pk)
        serializer = GameScheduleSerializer(game)
        return Response(serializer.data)

    def put(self, request, pk, format=None):
        game = self.get_object(pk)
        serializer = GameScheduleSerializer(game, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk, format=None):
        game = self.get_object(pk)
        game.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)"""
