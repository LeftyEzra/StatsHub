from django.shortcuts import render, get_object_or_404
from django.views import View
from ..models import Competition, GameSchedule

class GetGamesByDate(View):
    def get(self, request, competition_id, date):
        competition = get_object_or_404(Competition, pk=competition_id)
        games = GameSchedule.objects.filter(competition_game_schedule=competition, date=date).distinct()
        return render(request, 'organizer_competitions.html', {'games': games})
