from django.shortcuts import render, get_object_or_404
from django.views import View
from datetime import timedelta

from my_basketball_website.B_Ball.models import Organizer, Competition, Team, GameSchedule

class OrganizerCompetitionsView(View):
    def get(self, request, pk, *args, **kwargs):
        organizer = get_object_or_404(Organizer, pk=pk)
        competitions = Competition.objects.filter(organizers=organizer)

        competitions_with_dates = []
        for competition in competitions:
            date_range = []
            current_date = competition.start_date
            while current_date <= competition.end_date:
                games = GameSchedule.objects.filter(competition_game_schedule=competition, date=current_date).distinct()
                date_range.append({'date': current_date, 'games': games})
                current_date += timedelta(days=1)
            competitions_with_dates.append({
                'competition': competition,
                'dates': date_range,
            })

        teams = Team.objects.filter(competition__in=competitions).distinct()

        context = {
            'organizer': organizer,
            'competitions': competitions,
            'competitions_with_dates': competitions_with_dates,
            'teams': teams,
        }
        return render(request, 'organizer_competitions.html', context)
