$(document).ready(function() {
    console.log('Document is ready');

    function resetTables() {
        $("#gameDates, #teamSection, #gameSummary, #gameLeaders, #gameSchedule, #singleLeaders").hide();
    }

    $(".nav-link").click(function(event) {
        event.preventDefault();
        console.log('Nav link clicked:', $(this).attr('id'));

        $(".nav-link").removeClass("active");
        $(this).addClass("active");

        resetTables();

        if ($(this).attr('id') === 'teamList') {
            console.log('Team List link clicked');
            $("#teamSection").fadeIn("slow");
        } else if ($(this).attr('id') === 'game_Dates') {
            console.log('Home link clicked');
            $("#gameDates").fadeIn("slow");
            $("#gameSummary").fadeIn("slow");
            $("#gameLeaders").fadeIn("slow");
            $("#gameSchedule").fadeIn("slow");
            $("#singleLeaders").fadeIn("slow");
        } else if ($(this).attr('id') === 'playerList') {
            console.log('Player List link clicked');
            $("#playerSection").fadeIn("slow");
        } else {
            console.log($(this).text() + ' link clicked');
            window.location.href = $(this).attr('href');
        }
    });

    $("#gameDates").show();
    $("#gameSummary").show();
    $("#gameLeaders").show();
});

function loadGames(competition_id, date) {
    console.log('loadGames called with:', competition_id, date);

    const url = `/organizers/${competition_id}/games/${date}/`;
    console.log('Fetching URL:', url);

    $.get(url, function(data) {
        console.log('Data received:', data);

        const gameSummaryContent = $('#gameSummaryContent');
        gameSummaryContent.empty();
        data.forEach(function(game) {
            gameSummaryContent.append(`
                <div class="card-summary">
                    <div class="card-body-summary">
                        <h5 class="card-title-summary">${game.home_team}</h5>
                    </div>
                    <div class="card-body-summary">
                        <div class="flex-container">
                            <img src="${game.home_team_logo}" style="border-radius: 5%;" width="30" height="20">
                            <span>${game.home_team}</span>
                        </div>
                    </div>
                    <div class="card-body-3">
                        <h5 class="card-title-summary">Match Summary</h5>
                    </div>
                    <div class="card-body-summary">
                        <div class="flex-container">
                            <img src="${game.away_team_logo}" style="border-radius: 5%;" width="30" height="20">
                            <span>${game.away_team}</span>
                        </div>
                    </div>
                    <div class="card-body-summary">
                        <h5 class="card-title-summary">${game.date}</h5>
                    </div>
                </div>
            `);
        });
    });
}
